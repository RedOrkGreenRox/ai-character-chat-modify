# 01 — AI, изображения, аудио, голос

Плагины для генерации текста и изображений с помощью AI, а также работы с медиа.

---

## ✍️ ai-text-plugin — генерация текста AI

Генерирует текст (истории, стихи и т.п.) по инструкции. Работает **на серверных GPU** (не локально), поэтому:

> 💰 Для **не-залогиненных** пользователей внизу генератора появится **реклама** (так финансируются GPU-серверы). Уберёте плагин — реклама исчезнет.

### Подключение
```
ai = {import:ai-text-plugin}
```

### Базовый пример (в редакторе списков)
```
character
  {mech|demon|cyberpunk} {warrior|minion|samurai}

place
  a retropunk distopia
  a small village

season
  winter
  summer

poemPrompt
  instruction = Write a haiku about a [character] in [place] during [season].

output
  [ai(poemPrompt)]
```

Прямая передача текста интерпретируется как `instruction`:
```
output
  [ai("Explain quantum field theory to a toddler.")]
```

### Опции промпта
| Опция | Назначение |
|-------|-----------|
| `instruction` | Что AI должен написать |
| `startWith` | Текст, с которого должен начаться ответ AI |
| `stopSequences` | Слова/фразы, при генерации которых AI остановится |
| `hideStartWith` | `true` — не показывать сам текст `startWith` (только то, что после) |
| `outputTo` | Вывести ответ в элемент по его ID: `outputTo = [myCoolElement]` |
| `style` | CSS для визуального отображения вывода |
| `endButtons` | `none` — убрать кнопки edit/continue в конце ответа |
| `onStart(data)` | Код в начале генерации; доступ к `data.inputs.instruction`, `data.inputs.startWith` и т.д. |
| `onChunk(data)` | Код после каждого «чанка» (слово/часть слова); `data.textChunk`, `data.fullTextSoFar`, `data.isFromStartWith` |
| `onFinish(data)` | Код в конце; `data.text` (с `startWith`), `data.generatedText` (без), `data.liveResponseText` (с правками пользователя) |
| `render(data)` | Преобразует вывод перед показом (напр. `*действие*` → курсив); `data.text`, `data.isPartial` |

> `instruction`, `startWith`, `stopSequences` могут быть **функциями** (возвращают значение).

### Многострочный startWith
```
catGymPrompt
  startWith
    cat: i am a cat, and i'm calling to ask about your tuesday pilates classes
    kind staff member: sure! i can help you with-
    cat:
    $output = [this.joinItems("\n")] // объединяет строки вместо случайного выбора
```
> Используйте `\n`, а не `<br>` — модель обучена на тексте; `\n` корректно отображается как перенос.

### Использование в JS
```js
async start() =>
  let result = await ai({
    instruction: "write a poem",
    onChunk: function(data) { console.log("chunk:", data); },
  });
  console.log(result.generatedText, result);
```
- `result` сам по себе является строкой, равной `result.text` → можно писать `foo.innerHTML = result`.

### Важные заметки
- Текст промптов/ответов **не хранится на сервере**.
- У каждого пользователя лимит одновременных серверных запросов — лишние встают в очередь.
- Модель **может выдать NSFW-контент**, если её об этом попросить («как поиск Google»). Промптите ответственно.

> 🔗 В AI Character Chat этот же движок доступен как `oc.generateText({...})` — см. [Custom Code](../chat/06-custom-code.md).

---

## 🎨 text-to-image-plugin — генерация изображений AI

Генерирует картинку из текстового описания. Тоже серверный (с рекламой для не-залогиненных).

### Подключение
```
imageGen = {import:text-to-image-plugin}
```

### Параметры (синтаксис `(параметр:::значение)`)
В AI Character Chat доступны через `<image>...</image>` и `/image`:
- `resolution` — `512x768`, `512x512`, `768x512`.
- `seed` — фиксированный сид (повторяемый результат).
- `negativePrompt` — что НЕ должно быть на картинке.

В JS / Custom Code:
```js
let result = await oc.textToImage({
  prompt: "anime style robot, forest background, painterly textures",
  negativePrompt: "night time, blurry",
});
// result.dataUrl → "data:image/jpeg;base64,..."
```

> Полные опции и примеры — на странице <https://perchance.org/text-to-image-plugin>.

---

## 🖼️ Прочие плагины изображений

| Плагин | Описание | Подключение |
|--------|----------|-------------|
| **random-image-plugin** | Случайное изображение по теме/ключевому слову | `{import:random-image-plugin}` |
| **image-plugin** | Простой способ добавить изображения в генератор | `{import:image-plugin}` |
| **image-layer-combiner-plugin** | Случайно комбинировать/накладывать слои изображений (picrew/pokefusion) | `{import:image-layer-combiner-plugin}` |
| **pattern-maker-plugin** | Процедурные изображения, похожие на ваш input | `{import:pattern-maker-plugin}` |
| **flat-avatar-plugin** | Аватар со случайной одеждой, выражением лица, причёской | `{import:flat-avatar-plugin}` |

---

## 🔊 Аудио и голос

| Плагин | Описание | Подключение |
|--------|----------|-------------|
| **text-to-speech-plugin** | Браузер озвучивает сгенерированный текст | `{import:text-to-speech-plugin}` |
| **background-audio-plugin** | Фоновое аудио при посещении генератора | `{import:background-audio-plugin}` |

> 🔗 TTS можно стримить из ai-text-plugin (есть пример «Text-to-Speech») и из
> AI Character Chat через событие `StreamingMessage` ([Custom Code](../chat/06-custom-code.md)).
