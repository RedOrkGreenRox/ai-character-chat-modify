# 07 — Дополнительные и community-плагины

Плагины, которых **нет на официальной странице** [perchance.org/plugins](https://perchance.org/plugins), но которые активно используются сообществом. Собраны по [Perchance Wiki](https://perchance.fandom.com/wiki/Plugins) и обсуждениям на Reddit/Lemmy.

> ⚠️ **Важно про community-плагины.** Они «неофициальные»: автор может изменить или
> удалить плагин в любой момент, что **сломает** ваш генератор. Рекомендация
> разработчика Perchance — **форкнуть/ремикснуть** плагин (сохранить свою копию)
> и импортировать её, либо сделать «обёртку», импортирующую оригинал.

---

## 🔗 link-plugin — простые ссылки без HTML

Удобно делать ссылки, не зная HTML. (Автор: Raggedflight.)

```
link = {import:link-plugin}
```
Формат: `[link(url, текст, tab)]`
```
[link("https://perchance.org/tutorial/", "Example Link")]
[link("https://perchance.org/tutorial/", "Example Link", "newTab")]  // откроется в новой вкладке
```
- Для ссылки на другой генератор Perchance можно указать только имя: `[link("tutorial", "Example")]`.
- Не забывайте `https://` для внешних ссылок.

---

## 🎨 Набор «Power» (BluePower/Polygonal)

Серия полезных плагинов одного автора — модернизированные версии официальных:

| Плагин | Описание |
|--------|----------|
| **power-tabs-plugin** | Современная версия tabs-plugin |
| **power-spoiler-plugin** | Лёгкое создание «спойлер-текста» |
| **power-footer-plugin** | Добавить «подвал» (footer) странице |
| **power-shaker-plugin** | Трясёт страницу (на базе tornado-plugin) |
| **power-tagger-plugin** | Оборачивать текст разными HTML-тегами |
| **power-acronym-plugin** | Сокращает фразы в акронимы |
| **power-letter-sense-plugin** | Работа с буквами/символами |
| **raw-generator-stats-plugin** | Как generator-stats, но «сырые» значения |

---

## 🎲 Дополнительные кости и иконки

| Плагин | Описание |
|--------|----------|
| **dice-average-plugin** | Средний бросок для набора костей (на базе dice-plugin). ⚠️ Страница называется [dice-average](https://perchance.org/dice-average), без `-plugin` |
| **random-dice-icon-plugin** | Бросок как у dice-plugin, но с **визуальным отображением** кубиков |
| **icon-plugin** | Иконки из [Font Awesome](https://fontawesome.com/) |

---

## 🔤 Грамматика и персонажи

| Плагин | Описание |
|--------|----------|
| **pronoun-plugin** | Набор местоимений для подстановки в генератор |
| **gender-plugin** | Случайный пол с разными вероятностями |

---

## 🧩 Структура и утилиты

| Плагин | Описание |
|--------|----------|
| **nested-plugin-v2** | Улучшенная версия nested-plugin (иерархические «миры») |
| **to-array-plugin** | Преобразование списков Perchance в JavaScript-массивы |
| **color-palette-plugin** | Настраиваемая цветовая палитра |

---

## 🏳️ Декоративные/сезонные

| Плагин | Описание |
|--------|----------|
| **wiki-plugin** | Логотип, ведущий на Perchance Wiki |
| **perchance-logo-plugin** | Логотип Perchance настраиваемого размера |
| **pi-plugin** | Показывает «пирог» 14 марта (День числа Пи); по аналогии с pride-plugin |
| **ukraine-plugin** | Флаг Украины настраиваемого размера |

---

## 📚 Хабы плагинов сообщества

Где искать ещё (рекомендуется форкать перед использованием):

- **VioneT20** — <https://perchance.org/vionet20-gens>
- **BluePower / Polygonal (Power-*)** — <https://perchance.org/power-generator-manager>
- **Raggedflight** — <https://perchance.org/raggedflights-generators>
- **Indigo** — <https://perchance.org/plugins-page>
- **Eathams** — <https://perchance.org/eathams-pluginhub>
- **Dicemonger** — <https://perchance.org/dicemonger-generators>
- **«Ultimate JavaScript Plugin Collection»** — <https://perchance.org/premiumpluginsweirdstuff>
- **Полный список плагинов сообщества** — <https://perchance.org/plugin-list> и [Birdietalk Wiki](https://birdietalk-productions.fandom.com/wiki/The_Full_List_of_All_Plugins!)
- **Perchance Wiki: Plugins** — <https://perchance.fandom.com/wiki/Plugins>

> 🗑️ На вики также есть раздел **Discontinued Plugins** (устаревшие/неработающие) —
> их использовать не стоит.
