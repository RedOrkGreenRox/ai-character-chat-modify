# 04 — UI и вёрстка

Плагины для оформления генератора: макеты, кнопки, вкладки, фон, шрифты, навигация.

---

## 💬 comments-plugin — секция комментариев/чата

Встраивает блок комментариев/фидбэка (по сути, мини-чат) на страницу генератора. Поддерживает баны, slash-команды, кастомные эмодзи.

### Подключение
В панели Perchance:
```
commentsPlugin = {import:comments-plugin}
```
В HTML-панели:
```
[commentsPlugin()]
```

### Опции
```
commentOptions
	width = 300              // или 100% — на всю ширину
	height = 350
	commentPlaceholderText = Add a friendly comment.
	submitButtonText = submit comment
	hideComments = true     // показать только поле ввода + кнопку (виджет фидбэка)
	newestCommentsAtTop = true
	hideDates = true
```
Использование с опциями:
```
[commentsPlugin(commentOptions)]
```

### Несколько «каналов»
```
generalChatOptions
	channel = general-chat   // только строчные буквы, цифры, дефисы
feedbackOptions
	channel = feedback
	channelLabel = 💬 Отзывы  // отображаемое имя (любые символы)
```
> По умолчанию блок комментариев **не** обновляется при «randomize». Чтобы он
> заменялся свежим при каждой рандомизации (напр. свой чат в каждой «комнате»
> goto-квеста), добавьте `replacedDuringUpdate = true`.

### Кастомные эмодзи
```
commentOptions
  customEmojis
    cat_jam = https://user.uploads.dev/file/....webp
    surprise = ( ˶°ㅁ°) !!          // можно текст/каомодзи вместо URL
    kekw (tags:lol,lmao) = ....png   // теги для автоподсказок
```
Вызов в комментарии: `:catjam:`. Заметки:
- Картинки эмодзи **обязательно** загружать на [perchance.org/upload](https://perchance.org/upload).
- Триггеры эмодзи — только буквы/цифры/подчёркивания.
- Для огромного списка: `@import = {import:huge-emoji-list}` (80k+ эмодзи); >10k — только через URL текстового файла.
- Размер: рекомендуется ≤128×128 px; webp вместо gif (намного легче).
- Одиночный эмодзи в сообщении показывается крупнее (множитель ~1.8; настраивается `loneCustomEmojiSizeMultiplier`).
- Общий размер: `customEmojiSize = 2`; на отдельный эмодзи — `(size:2)`.

---

## 🎨 layout-maker-plugin — визуальные макеты без кода

Позволяет создавать собственные визуальные раскладки генератора без знания кода.
```
{import:layout-maker-plugin}
```

---

## 🧭 navbar-plugin — навигационная панель

Добавляет нав-бар, чтобы посетители видели все ваши работы.
```
{import:navbar-plugin}
```

---

## 🗂️ Вкладки, таблицы, кнопки

| Плагин | Описание |
|--------|----------|
| **tabs-plugin** | Вкладочный просмотрщик (tabbed viewer) |
| **make-table-plugin** | Упрощает создание HTML-таблиц |
| **fullscreen-button-plugin** | Кнопка перехода в полноэкранный режим |
| **download-button-plugin** | Кнопка «скачать генератор» (для офлайн-использования) |
| **print-button-plugin** | Кнопка печати сгенерированного контента |
| **copy-text-plugin** | Кнопка копирования вывода в буфер обмена |

---

## 🖼️ Фон, иконки, шрифты

| Плагин | Описание |
|--------|----------|
| **background-image-plugin** | Лёгкая установка фонового изображения генератора |
| **favicon-plugin** | Смена иконки вкладки браузера |
| **font-plugin** | Смена шрифтов через Google Fonts (для своих шрифтов — [custom-font-importer](https://perchance.org/custom-font-importer)) |
| **rpg-icon-plugin** | Доступ к набору ~500 RPG-иконок |
| **tooltip-plugin** | Тултипы/всплывашки при наведении на текст |

---

## ✨ Эффекты и взаимодействие

| Плагин | Описание |
|--------|----------|
| **typewriter-plugin** | Печать текста по символам (экспериментально) |
| **tornado-plugin** | Случайное вращение элементов страницы |
| **pride-plugin** | Радужный флаг на генераторе в июне (месяц прайда) |
| **press-enter-plugin** | Рандомизация по нажатию Enter |
| **tap-anywhere-plugin** | Рандомизация по тапу/клику в любом месте страницы |
| **tap-plugin** | Рандомизировать конкретные выводы тапом по ним (см. также раздел 03) |
