# Плагины Perchance — общее

Источник: <https://perchance.org/plugins>

## Что такое плагин

В Perchance можно импортировать другие генераторы в свой проект так:

```
{import:generator-name}
```

Это позволяет создавать маленькие, переиспользуемые, разделяемые «модули» — чтобы не изобретать колесо.

**Плагин** — это, по сути, такой импортируемый генератор: кто-то написал полезный HTML/код-сниппет и оформил его как «плагин», который вы импортируете в свою HTML-панель.

## Официальные vs. плагины сообщества

- **Официальные плагины** (перечислены на странице плагинов) — **никогда не будут удалены** и не получат изменений, ломающих импортировавшие их генераторы. Их безопасно использовать без форка.
- **Плагины сообщества (Community)** — **неофициальные**. Автор может в любой момент изменить плагин или даже удалить аккаунт, что сломает ваш генератор. Рекомендуется **форкнуть/ремикснуть** такой плагин (сохранить свою приватную копию и импортировать её).

### Ссылки на плагины сообщества
- [Fandom Community List](https://perchance.fandom.com/wiki/Plugins)
- [VioneT20 plugins](https://perchance.org/vionet20-gens)
- [BluePower/Polygonal plugins](https://perchance.org/power-generator-manager)
- [Raggedflight's plugins](https://perchance.org/raggedflights-generators)
- [Indigo's plugins](https://perchance.org/plugins-page)
- [Eathams's plugins](https://perchance.org/eathams-pluginhub)
- [Dicemonger's plugins](https://perchance.org/dicemonger-generators)

Нужен плагин? Спросите на [форуме](https://lemmy.world/c/perchance). Также полезны страницы [templates](https://perchance.org/templates) и [preprocessors](https://perchance.org/preprocessors).

---

## Навигация по тематическим страницам

- [01 — AI, изображения, аудио, голос](01-ai-and-media.md)
- [02 — Данные и хранение](02-data-and-storage.md)
- [03 — Случайность и списки](03-randomness-and-lists.md)
- [04 — UI и вёрстка](04-ui-and-layout.md)
- [05 — Текст и язык](05-text-and-language.md)
- [06 — Прочие инструменты](06-misc-and-tools.md)
- [07 — Дополнительные и community-плагины](07-community-and-extra-plugins.md)
- [99 — Полный алфавитный указатель](99-full-index.md)
- [🔗 Анализ синергий между плагинами](../analysis/plugin-synergies.md)
- [🎲 Индекс интересных генераторов сайта](../generators/00-index.md)

> Каждый плагин снабжён ссылкой `https://perchance.org/<имя-плагина>` — там полная
> страница с примерами кода. Здесь даны структурированные описания на русском.
