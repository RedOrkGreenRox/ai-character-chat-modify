# Полный указатель официальных плагинов Perchance

Полный список всех официальных плагинов со страницы <https://perchance.org/plugins>, с переводом назначения и ссылкой на оригинальную страницу.

> Каждый плагин подключается импортом: `{import:имя-плагина}`. Подробные примеры — по ссылке.

## AI / медиа / голос
| Плагин | Назначение |
|--------|-----------|
| [text-to-image-plugin](https://perchance.org/text-to-image-plugin) | Сгенерировать изображение из текстового описания с помощью AI |
| [ai-text-plugin](https://perchance.org/ai-text-plugin) | Генерация текста (истории, стихи и т.п.) по инструкции |
| [random-image-plugin](https://perchance.org/random-image-plugin) | Случайное изображение по теме/ключевому слову |
| [image-plugin](https://perchance.org/image-plugin) | Простой способ добавить изображения в генератор |
| [image-layer-combiner-plugin](https://perchance.org/image-layer-combiner-plugin) | Случайно комбинировать/накладывать наборы изображений (как picrew/pokefusion) |
| [pattern-maker-plugin](https://perchance.org/pattern-maker-plugin) | Процедурные изображения, похожие на ваш input |
| [flat-avatar-plugin](https://perchance.org/flat-avatar-plugin) | Аватар со случайной одеждой, выражением, причёской и т.п. |
| [text-to-speech-plugin](https://perchance.org/text-to-speech-plugin) | Озвучивание сгенерированного текста браузером |
| [background-audio-plugin](https://perchance.org/background-audio-plugin) | Фоновое аудио при посещении генератора |

## Данные / хранение / сеть
| Плагин | Назначение |
|--------|-----------|
| [kv-plugin](https://perchance.org/kv-plugin) | Хранение данных, доступных после перезагрузки/закрытия страницы |
| [remember-plugin](https://perchance.org/remember-plugin) | Сохранять переменные, чтобы они не терялись при перезагрузке |
| [secret-plugin](https://perchance.org/secret-plugin) | Шифрование/дешифрование данных (с полезным «твистом») |
| [upload-plugin](https://perchance.org/upload-plugin) | Программная загрузка файлов на сервер Perchance |
| [super-fetch-plugin](https://perchance.org/super-fetch-plugin) | Скачать любую страницу/данные (обход CORS) |
| [url-params-plugin](https://perchance.org/url-params-plugin) | Считывать и использовать URL-параметры |
| [google-sheets-plugin](https://perchance.org/google-sheets-plugin) | Импорт списков из Google Sheets |
| [generator-stats-plugin](https://perchance.org/generator-stats-plugin) | Счётчик просмотров и статистика генератора |
| [seeder-plugin](https://perchance.org/seeder-plugin) | Копируемые «сиды»: один сид = один результат |
| [fixed-until-reload-plugin](https://perchance.org/fixed-until-reload-plugin) | Значения рандомизируются только при перезагрузке |
| [bug-report-plugin](https://perchance.org/bug-report-plugin) | Шифрует debug-данные браузера для баг-репортов |

## Случайность / списки / выбор
| Плагин | Назначение |
|--------|-----------|
| [create-instance-plugin](https://perchance.org/create-instance-plugin) | «Чертежи» объектов и создание их случайных экземпляров |
| [create-instances-plugin](https://perchance.org/create-instances-plugin) | Список случайных экземпляров по чертежу |
| [random-integer-plugin](https://perchance.org/random-integer-plugin) | Случайное целое между двумя числами |
| [random-decimal-plugin](https://perchance.org/random-decimal-plugin) | Случайное дробное число между двумя числами |
| [random-select-plugin](https://perchance.org/random-select-plugin) | Случайный выбор из входов с заданными шансами |
| [dice-plugin](https://perchance.org/dice-plugin) | Броски кубиков нотацией вида «2d8» |
| [roll-table-plugin](https://perchance.org/roll-table-plugin) | Диапазоны кубиков для элементов списка вместо нотации шансов |
| [wheel-plugin](https://perchance.org/wheel-plugin) | «Колесо фортуны» |
| [select-range-plugin](https://perchance.org/select-range-plugin) | Выбрать определённый диапазон элементов из списка |
| [select-until-plugin](https://perchance.org/select-until-plugin) | Повторять selectOne, пока результат не удовлетворит условию |
| [select-leaf-plugin](https://perchance.org/select-leaf-plugin) | Выбрать «лист» из иерархии |
| [select-leaves-plugin](https://perchance.org/select-leaves-plugin) | Версия selectLeaf для selectMany |
| [select-all-leaves-plugin](https://perchance.org/select-all-leaves-plugin) | Версия selectLeaf для selectAll |
| [consumable-leaf-list-plugin](https://perchance.org/consumable-leaf-list-plugin) | consumableList из «листьев» иерархии |
| [consumable-list-loop-plugin](https://perchance.org/consumable-list-loop-plugin) | Расходуемый список, который сбрасывается, когда опустеет |
| [lockable-list-plugin](https://perchance.org/lockable-list-plugin) | Кнопки «замок»: оставить выбор и рандомизировать остальное |
| [locker-plugin](https://perchance.org/locker-plugin) | Более мощная версия lockable-list |
| [join-lists-plugin](https://perchance.org/join-lists-plugin) | Объединить два+ списка/элемента в один список |
| [exclude-items-plugin](https://perchance.org/exclude-items-plugin) | Исключить элементы из списка при случайном выборе |
| [filter-list-plugin](https://perchance.org/filter-list-plugin) | Продвинутая динамическая фильтрация списков |
| [sum-odds-plugin](https://perchance.org/sum-odds-plugin) | Суммировать шансы списка (для слияния с сохранением шансов) |
| [number-set-plugin](https://perchance.org/number-set-plugin) | Набор чисел, дающих в сумме заданное число |
| [markov-chain-plugin](https://perchance.org/markov-chain-plugin) | Случайный текст по большому корпусу (цепи Маркова) |
| [tap-plugin](https://perchance.org/tap-plugin) | Рандомизировать конкретные выводы тапом/кликом |

## UI / вёрстка / медиа-оформление
| Плагин | Назначение |
|--------|-----------|
| [layout-maker-plugin](https://perchance.org/layout-maker-plugin) | Создавать визуальные макеты без кода |
| [navbar-plugin](https://perchance.org/navbar-plugin) | Добавить нав-бар в генератор |
| [tabs-plugin](https://perchance.org/tabs-plugin) | Вкладки (tabbed viewer) |
| [make-table-plugin](https://perchance.org/make-table-plugin) | Упростить создание HTML-таблиц |
| [favicon-plugin](https://perchance.org/favicon-plugin) | Сменить иконку вкладки браузера |
| [background-image-plugin](https://perchance.org/background-image-plugin) | Фоновое изображение генератора |
| [font-plugin](https://perchance.org/font-plugin) | Менять шрифты через Google Fonts (для своих — custom-font-importer) |
| [rpg-icon-plugin](https://perchance.org/rpg-icon-plugin) | ~500 RPG-иконок |
| [tooltip-plugin](https://perchance.org/tooltip-plugin) | Тултипы/всплывашки при наведении на текст |
| [tornado-plugin](https://perchance.org/tornado-plugin) | Случайное вращение элементов страницы |
| [typewriter-plugin](https://perchance.org/typewriter-plugin) | Печать текста по символам (экспериментально) |
| [pride-plugin](https://perchance.org/pride-plugin) | Радужный флаг в июне (месяц прайда) |
| [press-enter-plugin](https://perchance.org/press-enter-plugin) | Рандомизация по нажатию Enter |
| [tap-anywhere-plugin](https://perchance.org/tap-anywhere-plugin) | Рандомизация по тапу/клику в любом месте |
| [fullscreen-button-plugin](https://perchance.org/fullscreen-button-plugin) | Кнопка полноэкранного режима |
| [download-button-plugin](https://perchance.org/download-button-plugin) | Кнопка скачать генератор для офлайн-использования |
| [print-button-plugin](https://perchance.org/print-button-plugin) | Кнопка печати сгенерированного |
| [copy-text-plugin](https://perchance.org/copy-text-plugin) | Кнопка копирования вывода в буфер |

## Текст / язык / числа
| Плагин | Назначение |
|--------|-----------|
| [markdown-plugin](https://perchance.org/markdown-plugin) | Альтернатива HTML: текст → HTML |
| [literal-plugin](https://perchance.org/literal-plugin) | Авто-экранирование `{}` и `[]` обратными слэшами |
| [title-case-plugin](https://perchance.org/title-case-plugin) | «Умный» Title Case |
| [conjugate-plugin](https://perchance.org/conjugate-plugin) | Спряжения глаголов сверх простых форм |
| [a-an-plugin](https://perchance.org/a-an-plugin) | Замена `{a}`, лучше работающая с плагинами вроде tap-plugin |
| [be-plugin](https://perchance.org/be-plugin) | Авто-замена на is/are по контексту (местоимению) |
| [plural-plugin](https://perchance.org/plural-plugin) | Замена pluralForm с поддержкой кастомных форм мн. числа |
| [numerals-to-words-plugin](https://perchance.org/numerals-to-words-plugin) | «453» → «four hundred and fifty three» |
| [numerals-to-ordinal-words-plugin](https://perchance.org/numerals-to-ordinal-words-plugin) | «453» → «four hundred and fifty third» |
| [numerals-to-ordinals-plugin](https://perchance.org/numerals-to-ordinals-plugin) | «453» → «453rd» |
| [roman-numerals-plugin](https://perchance.org/roman-numerals-plugin) | Число → римские цифры |
| [date-plugin](https://perchance.org/date-plugin) | Работа с датами и их форматирование |

## Прочее / инструменты / структура
| Плагин | Назначение |
|--------|-----------|
| [comments-plugin](https://perchance.org/comments-plugin) | Встроить секцию комментариев/фидбэка |
| [docs-plugin](https://perchance.org/docs-plugin) | Многостраничная документация на markdown |
| [goto-plugin](https://perchance.org/goto-plugin) | Простые текстовые квесты (text adventures) |
| [nested-plugin](https://perchance.org/nested-plugin) | Иерархические случайные «миры» |
| [dynamic-import-plugin](https://perchance.org/dynamic-import-plugin) | Импорт сотен генераторов без роста времени загрузки |
| [tldraw-plugin](https://perchance.org/tldraw-plugin) | Совместный холст для рисования с друзьями |

> Итого: это **полный** перечень официальных плагинов со страницы Perchance Plugins.
> Тематические разборы наиболее используемых — в файлах 01–06.
