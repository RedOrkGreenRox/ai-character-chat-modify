# 🎲 Индекс интересных генераторов Perchance

Подборка заметных генераторов сайта — официальных (от разработчика) и community
(сделанных пользователями). Составлено по официальным хабам, Perchance Wiki и
обсуждениям сообщества (Reddit r/perchance, Lemmy).

> 🔎 Совет по поиску: у Perchance слабый встроенный поиск. Используйте Google так:
> `<запрос> site:perchance.org`. Хабы: [perchance.org/perlist](https://perchance.org/perlist),
> [perchance.org/all-plugins](https://perchance.org/all-plugins),
> [perchance.org/hub](https://perchance.org/hub).
>
> ⚠️ Многие AI-генераторы Perchance **намеренно без фильтров** (могут давать
> NSFW-контент по запросу). Промптите ответственно.

---

## 🗣️ AI-чат и ролевые игры

### Официальные (от разработчика)
| Генератор | URL | Описание |
|-----------|-----|----------|
| **AI Character Chat (ACC)** | [/ai-character-chat](https://perchance.org/ai-character-chat) | Флагман: чат с AI-персонажами, кастомные персонажи, лорбуки, генерация картинок в чате. Именно ему посвящена [Часть 1](../chat/01-tips.md) этой документации |
| **AI Chat** | [/ai-chat](https://perchance.org/ai-chat) | Более простой AI-чат |
| **AI Group Chat** | [/all-plugins](https://perchance.org/all-plugins) | Групповой чат с несколькими AI |
| **AI RPG / Text Adventure** | [/ai-rpg](https://perchance.org/ai-rpg) | Текстовое приключение в духе AI Dungeon с AI-гейммастером |

### Community-форки ACC (по обсуждениям 2026)
| Генератор | URL | Чем интересен |
|-----------|-----|---------------|
| **NACG** (New AI Chat Gen) | [/new-ai-chat-gen](https://perchance.org/new-ai-chat-gen) | Редактор MPT, «ползунок креативности», фикс em-dash, улучшенное суммирование |
| **URV AI Chat** | [/urv-ai-chat](https://perchance.org/urv-ai-chat) | Мульти-модельность (Pollinations API), импорт SillyTavern, чистый UI |
| **TPS Group Chat** | [/tps-ai-character-chat-groupchat](https://perchance.org/tps-ai-character-chat-groupchat) | Автономный групповой ролеплей |
| **Petrafied ACC** | [/petrafied-acc](https://perchance.org/petrafied-acc) | Универсальный форк с просмотром галереи |
| **Gemini Chat** (poor_adrian) | [/gemini-chat](https://perchance.org/gemini-chat) | Подключение внешних API-провайдеров по ключу (SillyTavern-стиль) |
| **ACC (old)** | [/ai-character-chat-old](https://perchance.org/ai-character-chat-old) | Прежняя версия/поведение |
| **FurAI** | [/fur-ai](https://perchance.org/fur-ai) | Групповой RP по умолчанию + режим «визуальной новеллы» со спрайтами |
| **AI Chat Modern** | — | То же, что AI Chat, но с более чистым UI |
| **DarLink AI** | — | Чат/RP с хорошей памятью + генерация изображений/видео |

> 📖 **Подробный разбор форков** (фичи, авторы, компромиссы, как выбрать) —
> в отдельном файле: [01-acc-forks.md](01-acc-forks.md).
>
> Зачем форки? У базового ACC есть ограничения (контекст ~8K токенов, нет облачных
> сохранений). Форки добавляют контроль над промптом, мульти-модельность, UI-улучшения.
> Подробнее о работе с ограничениями — в [Память и Лор](../chat/04-memories-and-lore.md).

---

## 🎨 Генерация изображений

### Официальные
| Генератор | URL | Описание |
|-----------|-----|----------|
| **AI Text-to-Image Generator** | [/ai-text-to-image-generator](https://perchance.org/ai-text-to-image-generator) | Главный генератор картинок (для многих — «точка входа» в Perchance) |
| **AI Image Generator (Pro)** | [/image-generator-professional](https://perchance.org/image-generator-professional) | Профи-версия с расширенным контролем |
| **AI Human Generator** | [/ai-human-generator](https://perchance.org/ai-human-generator) | Реалистичные/стилизованные люди (лицо или в полный рост) |
| **AI Photo Generator** | [/all-plugins](https://perchance.org/all-plugins) | Фотореалистичные изображения |

### Community
| Генератор | URL | Чем интересен |
|-----------|-----|---------------|
| **AI Art Generator Advanced** | — | Расширенный контроль над генерацией |
| **AI Artgen** | [/ai-artgen](https://perchance.org/ai-artgen) | Аккуратный, организованный UI |
| **AI Furry Generator** | [/ai-furry-generator](https://perchance.org/ai-furry-generator) | Сообществ-ориентированный, в духе оригинальной эстетики Perchance |
| **ArtScape (v3)** | [/artscapes-v3](https://perchance.org/artscapes-v3) | SFW-ориентированный (через regex-ограничения ввода) |
| **Anime AI Generator** | — | Популярен для аниме-стиля |
| **ImageGlitch** | [/imageglitch](https://perchance.org/imageglitch) | Минималистичный, без лишнего |
| **Free No Limit AI Image Generator** | [/y06fzf5rev](https://perchance.org/y06fzf5rev) | Расширенные контролы + чат + галерея изображений |

---

## ✍️ Генерация текста и письмо

| Генератор | URL | Описание |
|-----------|-----|----------|
| **AI Story Generator / Story Writer** | [/ai-story-generator](https://perchance.org/ai-story-generator) | Генерация историй |
| **AI Text Rewriter** | [/all-plugins](https://perchance.org/all-plugins) | Переписывание текста |
| **AI Plot Generator** | [/all-plugins](https://perchance.org/all-plugins) | Сюжеты из промптов |
| **AI Story Outline / Plot Generator** | — | План истории (сюжет, персонажи) с обложкой |
| **AI Poem / Lyrics / Rap Lyrics Generator** | — | Стихи, тексты песен, рэп |
| **AI Fanfic / Script Generator** | — | Фанфики, сценарии |
| **AI Character Description Generator** | — | Описания персонажей |
| **story-ai** | [/story-ai](https://perchance.org/story-ai) | Художественная проза абзац за абзацем |

> Полный список AI-генераторов текста — на [perchance.org/all-plugins](https://perchance.org/all-plugins).

---

## 🛠️ Инструменты и утилиты

| Генератор | URL | Описание |
|-----------|-----|----------|
| **Question This** (VioneT) | — | Создание собственных вопросов/викторин, высоко настраиваемый |
| **Banner / Collage Maker** | [/collage-banner-maker](https://perchance.org/collage-banner-maker) | Простой коллаж/баннер-мейкер |
| **Pergens** | [/pergens](https://perchance.org/pergens) | Хаб генераторов с улучшенным UI |
| **AI Character Chat Docs** | [/ai-character-chat-docs](https://perchance.org/ai-character-chat-docs) | Официальная документация (первоисточник Части 1) |
| **Upload** | [/upload](https://perchance.org/upload) | Хостинг файлов (для лорбуков, аватаров, эмодзи) |
| **Custom Font Importer** | [/custom-font-importer](https://perchance.org/custom-font-importer) | Импорт своих шрифтов |

---

## 📚 Обучение и навигация по сайту

| Ресурс | URL | Описание |
|--------|-----|----------|
| **Examples** | [/examples](https://perchance.org/examples) | Учебные примеры синтаксиса Perchance |
| **More Examples** | [Wiki: More Examples](https://perchance.fandom.com/wiki/More_Examples) | Дополнительные примеры (в т.ч. комбо плагинов) |
| **Tutorial** | [/tutorial](https://perchance.org/tutorial) | Базовый туториал |
| **Templates** | [/templates](https://perchance.org/templates) | Шаблоны генераторов |
| **Plugins** | [/plugins](https://perchance.org/plugins) | Официальный список плагинов |
| **Perchance Wiki** | [perchance.fandom.com](https://perchance.fandom.com/wiki/Main_Page) | Вики-документация сообщества |
| **Forum (Lemmy)** | [lemmy.world/c/perchance](https://lemmy.world/c/perchance) | Официальный форум |
| **Reddit** | [r/perchance](https://www.reddit.com/r/perchance/) | Сообщество, подборки, помощь |

> ℹ️ Существуют сторонние сайты с похожими названиями (perchanceaigenerator.com и т.п.) —
> это **не** официальный Perchance. Официальный домен — **perchance.org**.
