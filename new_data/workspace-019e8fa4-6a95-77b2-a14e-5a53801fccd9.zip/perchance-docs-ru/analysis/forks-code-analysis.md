# 🔬 Технический анализ кода форков AI Character Chat

Разбор **исходного кода** форков, полученного через `<url>#edit` (открывает редактор
Perchance). Анализ показывает, что именно меняет каждый форк относительно
официального ACC, на уровне архитектуры и кода.

> **Как это получено.** Приписка `#edit` к URL генератора открывает встроенный
> редактор Perchance. Левая панель — «lists/код» (логика на perchance-синтаксисе +
> JS), правая нижняя — HTML/шаблон. Код виден всем (генераторы открыты), но
> выполняется в песочнице.
>
> ⚠️ Анализ по состоянию на дату сборки. Авторы пушат «живые обновления» —
> конкретные строки могут измениться.

---

## Общая архитектура ACC (что наследуют все форки)

Почти все ACC-форки используют один и тот же «движок», построенный на официальных плагинах:

```
loadDependencies   = {import:ai-character-chat-dependencies-v1}  // dexie.js (IndexedDB), dompurify (санитайзер HTML) и т.п.
aiTextPlugin       = {import:ai-text-plugin}        // генерация текста (серверные GPU)
textToImagePlugin  = {import:text-to-image-plugin}  // генерация картинок
commentsPlugin     = {import:comments-plugin}       // комьюнити/фидбэк
uploadPlugin       = {import:upload-plugin}         // ← для share-ссылок персонажей
superFetch         = {import:super-fetch-plugin}    // обход CORS в кастомном коде персонажей
fullscreenButtonPlugin = {import:fullscreen-button-plugin}
combineEmojis      = {import:combine-emojis-plugin}
bugReport          = {import:bug-report-plugin}      // debug-инфо для баг-репортов
```

**Ключевые наблюдения из кода:**

1. **Хранение — IndexedDB через Dexie.** В коде `window.dbName="chatbot-ui-v1"` (или
   `"chatbot-ui-v1"` варианты). Подтверждает: чаты лежат в браузере, **не на сервере**
   — отсюда предупреждения о бэкапах ([Память и Лор](../chat/04-memories-and-lore.md)).

2. **Share-ссылки = gzip + загрузка файла.** Механизм `generateShareLinkForCharacter`:
   - `JSON.stringify(json)` персонажа/чата;
   - сжатие через нативный `CompressionStream('gzip')`;
   - загрузка blob через `uploadPlugin` → получение `.gz`-файла на `user.uploads.dev`;
   - итоговая ссылка вида `?data=ИмяПерсонажа~ХЕШ.gz`.
   - Загрузка обратно: `loadDataFromUrlThatReferencesCloudStorageFile` →
     `DecompressionStream("gzip")` → `JSON.parse`.
   - **Вывод:** «облачные» персонажи — это просто публичные gzip-файлы; самого чата
     на сервере по-прежнему нет.

3. **Песочница для кода персонажей.** `evaluatePerchanceTextInSandbox` создаёт скрытый
   `<iframe>` на отдельном поддомене (`...perchance.org/ai-character-chat-sandboxed-executor`)
   с `sandbox="allow-scripts allow-same-origin"` и общается с ним через `postMessage`.
   - **Вывод:** кастомный код персонажа (см. [Custom Code](../chat/06-custom-code.md))
     изолирован — поэтому чужой персонаж не может украсть ваши данные.

4. **Модерация при шаринге.** В NACG-версии `generateShareLinkForCharacter` есть
   обработка ошибки `disallowed_content` с подсказкой «укажите, что персонажу 18+,
   если модерация ошиблась из-за неоднозначности». То есть **аплоад проходит
   AI-модерацию**, даже если чат «без фильтров».

---

## NACG — New AI Chat Gen

**Что это по коду:** наиболее «верный» форк ACC (тот же движок share-link, тот же
sandboxed executor), но с надстройками для контента и UX.

**Отличия, видимые в коде:**

- **Динамические боты через `dynamic-import-plugin`:**
  ```
  FreemanBots   = [dynamicImport('sjjhkyohfs')]
  PelicanBots   = [dynamicImport('uf77qdls1x')]
  BegginnerBots = [dynamicImport('7876aw570s')]
  BGLBots       = [dynamicImport('nfmzi31r2m')]
  ```
  Наборы ботов от разных авторов (Yana, Begginer43, Pelicanman44, Freeman)
  подгружаются **лениво**, не раздувая загрузку → это та самая синергия с
  dynamic-import из [анализа синергий](plugin-synergies.md).

- **Свой плагин комментариев:** `nacgAiComments = {import:nacg-ai-comments}` плюс
  `tabbed-comments-plugin` (вкладочные комментарии с `middleCtnChannelNameToObj`).

- **`$meta.dynamic(inputs)`** — динамические заголовок/описание/превью страницы в
  зависимости от URL-параметров (`?char=...` или `?data=...`). В описании прямо
  заявлены фичи: «**adjust the Main Prompt (MPT)**», «free image generation in every
  bot», RPG/Anime/SFW/NSFW-боты, Changelog и Guide.

- **`urlNamedCharacters`** — именованные персонажи по короткому URL (`?char=psychologist`,
  `?char=ai-adventure`, `?char=story-writer` и т.п.) → маппинг на `.gz`-файлы.

**Вывод:** NACG = ACC-движок + контент-платформа (боты, эмодзи, шаблоны) + **MPT**
(пользовательский контроль над главным промптом). MPT-редактор и фиксы (em-dash,
бан-листы) реализованы поверх стандартного `ai-text-plugin`, а не заменой модели.

---

## TPS Group Chat и Petrafied ACC — «семейство TPS»

**Открытие:** код TPS Group Chat и Petrafied ACC **почти идентичен** — оба используют
один набор расширений:

```
tpsImageGenerator    = {import:tps-ai-image-generator}
generateImageGenHTML = {import:tps-text-to-image-framework}  // фреймворк-плагин, сам импортирует text-to-image и строит UI
// characterSearchHTML = {import:tps-character-search-framework}  // (закомментирован)
imageGenSettings     = [tpsImageGenerator.settings]
```

**Отличия от базового ACC:**
- Собственный **фреймворк генерации изображений** (`tps-text-to-image-framework`) —
  обёртка над официальным text-to-image с готовым UI и настройками
  (`tpsImageGenerator.settings`). Это объясняет более богатый image-UI у этих форков.
- Заготовка под **поиск персонажей** (`tps-character-search-framework`, пока выключен).
- Share-link использует домен `user-uploads.perchance.org` (в «классических» форках),
  тогда как NACG — `user.uploads.dev`. Это просто разные базовые версии ACC.

**Вывод:** Petrafied и TPS — родственники, выросшие из одной кодовой ветки с
TPS-фреймворками. Отличие TPS — групповая логика (автономные мульти-персонажи)
поверх этого общего базиса; Petrafied добавляет просмотр галереи.

---

## Gemini Chat (poor_adrian) — самый технически интересный

**Это не косметический форк, а перехват «мозга» чата.** Вместо использования
официального `ai-text-plugin` напрямую, он **оборачивает** его:

```js
nativeAiTextPlugin = {import:ai-text-plugin}

aiTextPlugin(opts) =>
  // 1. Проверка настроек: если выбран Gemini — возвращаем "виртуальный" плагин
  if(opts && opts.getMetaObject) {
    let useGemini = window.userSettings_aiProvider === "gemini";
    if(useGemini) return { idealMaxContextTokens: 800000, countTokens: (s) => Math.ceil((s||"").length/4) };
    return nativeAiTextPlugin(opts);
  }
  // 2. Служебные запросы всегда идут в нативный плагин Perchance:
  let isMemoryQuery = (opts.startWith||"").includes("MEMORY SEARCH QUERIES");
  let isSummary     = (opts.instruction||"").includes("concisely compresses");
  let isAutoNaming  = (opts.instruction||"").includes("chat thread naming assistant");
  let provider = window.userSettings_aiProvider || (window.userSettings_useGemini ? "gemini" : "default");
  if(provider === "default" || isMemoryQuery || isSummary || isAutoNaming)
    return nativeAiTextPlugin(opts);
  // 3. Иначе — собственный fetch к внешнему провайдеру (OpenAI-совместимый)...
```

**Что это даёт и как устроено:**

- **Гибридная маршрутизация.** Память/суммирование/авто-нейминг тредов остаются на
  бесплатном движке Perchance (распознаются по тексту промпта!), а **основные
  ответы** идут на выбранную внешнюю модель. Умно: тяжёлые «фоновые» вызовы не жгут
  ваш внешний API-лимит.
- **OpenAI-совместимый стриминг** (`fetchOpenAIStandard`): `POST` с
  `Authorization: Bearer <key>`, `stream:true`, чтение `ReadableStream`, парсинг
  `data: {...}` SSE, выдача чанков через `opts.onChunk` — ровно как [стриминг в
  Custom Code](../chat/06-custom-code.md).
- **Огромный контекст для Gemini:** `idealMaxContextTokens: 800000` (против ~8K у
  базового ACC) — отсюда репутация «лучшей памяти» у мульти-API форков.
- **Самодельный trimming контекста:** при превышении лимита оставляет 25% начала и
  75% конца промпта, вставляя `[... Middle messages omitted ...]` — простая, но
  рабочая стратегия сохранения «начала сцены + свежих сообщений».
- **Поддержка локальных бэкендов:** в коде упоминается «LM Studio fix» (кастомная
  структура `messages`) → можно подключать локальные модели.

**Security (важно, прямо в UI генератора):**
- Ключи API хранятся **локально** в IndexedDB, не уходят на сервер автора.
- Подключение только к Perchance и выбранному провайдеру.
- **Жёсткое требование форкнуть генератор**: автор может пушить live-обновления, и
  если его аккаунт взломают — обновлённый код мог бы украсть ключи. Поэтому: создать
  аккаунт → edit → save → получить «замороженную» приватную копию.
- Призыв проверить код (или скормить его AI на проверку «нет ли эксфильтрации»).

**Вывод:** Gemini Chat / мульти-API форки превращают ACC в **SillyTavern-подобный
фронтенд**: вы приносите свой API-ключ, выбираете провайдера (Gemini, OpenAI-совместимые,
Pollinations, локальные), а Perchance остаётся «бесплатным» для служебных задач.

---

## URV AI Chat (WithThatWay) — переписан с нуля

**Это самый «непохожий» форк** — не наследует ACC-движок, а написан как отдельное
приложение поверх Pollinations.

**Что видно в коде:**

- **Другой стек импортов:**
  ```
  kv      = {import:kv-plugin}            // хранилище
  generateText = {import:ai-text-plugin}
  image   = {import:text-to-image-plugin}
  ver     = {import:sha256-verification}  // верификация/хеши
  forum   = {import:comments-plugin}
  liveActivityPlugin = {import:live-activity-plugin}  // онлайн-активность
  upload  = {import:upload-plugin}
  ```

- **Мульти-модельность (видно в UI/конфиге):** список моделей включает
  DeepSeek R1-Distill-Llama-70B, Amazon Nova-Micro, Google Gemma, Mistral-Small-3.2,
  Meta-Llama-4-Scout, Qwen3-Coder-30B, StepFun-3.5 и др., с тегами
  `Text / Hybrid / Reasoning / Vision`. Модели изображений/видео: `flux-nsfw`,
  `klein`, `ltx-2` (видео!), с выбором соотношения сторон (1:1, 2:3, 9:16, 16:9, 21:9…).

- **Кнопки действий (роли):** Narrator / AI / User (impersonate) / Image / Char /
  System / Memory (pinned anchors) / Summary — это аналог slash-команд ACC
  (`/nar`, `/ai`, `/user`, `/image`, `/sys`), но как UI-кнопки.

- **Серьёзный contentFilter на regex.** В `galleryOptions.bannedPromptPhrases` — большие
  регэкспы, банящие анатомическую лексику (и, в одном из закомментированных вариантов,
  даже религиозную одежду/титулы). Плюс `contentFilter = pg13` по умолчанию,
  `hideIfScoreIsBelow`, `bannedUsers` (список SHA-256 хешей).
  - **Нюанс:** несмотря на маркетинг «uncensored», в **публичной галерее** действует
    жёсткая фильтрация ввода через regex (это подтверждает наблюдение сообщества про
    ArtScape/regex-ограничения).

- **Тема Tokyo Night.** Все стили (`messageBubbleStyle`, `containerStyle` и т.п.)
  захардкожены в палитре Tokyo Night (`#1a1b26`, `#24283b`, `#414868`, `#c0caf5`),
  иконки шестерёнки/фуллскрина — инлайновые SVG в `data:`-URI.

- **Кастомные эмодзи + slash-команды** через comments-plugin (`@import = {import:huge-emoji-list}`,
  команда `/addemoji`) — синергия из [анализа](plugin-synergies.md).

- **Экономика честно показана:** в коде есть announcement-модалка о риске потери
  бесплатного тира с 22 июня (тогда останутся только Perchance-модели). Подтверждает:
  внешние модели держатся на средствах автора/Pollinations и **нестабильны**.

**Вывод:** URV — это полноценный кастомный фронтенд (мульти-модель текст+картинки+видео,
Vision-модели для анализа загруженных изображений, своя тема), а ACC-совместимость
ограничена (отсюда «Lorebook: Limited» в сводной таблице). Цена гибкости — слабее
художественный текст и зависимость от внешней инфраструктуры.

---

## Сводка: что меняет каждый форк (по коду)

| Форк | Базис | Главное изменение в коде | Где «мозг» (LLM) |
|------|-------|--------------------------|-------------------|
| **ACC (офиц.)** | — | эталон | Perchance (`ai-text-plugin`) |
| **NACG** | ACC-движок | dynamic-import боты, nacg-ai-comments, MPT, `$meta.dynamic` | Perchance |
| **TPS Group Chat** | ветка TPS | `tps-text-to-image-framework` + групповая логика | Perchance |
| **Petrafied ACC** | ветка TPS | TPS-фреймворки + галерея | Perchance |
| **Gemini Chat** | ACC-движок | **обёртка `aiTextPlugin`** с маршрутизацией на внешние API | внешние (Gemini/OpenAI-совм./локальные) + Perchance для служебного |
| **URV AI** | переписан | свой UI, мульти-модель (Pollinations), Vision, видео, Tokyo Night, regex-фильтры | внешние (Pollinations) + Perchance |

---

## Главные технические инсайты

1. **«Облако» Perchance ≈ публичные gzip-файлы.** Share-ссылки и «cloud backup» —
   это сжатые JSON, загруженные через upload-plugin. Сами чаты остаются в IndexedDB
   браузера. Бэкапьтесь.

2. **Кастомный код персонажей реально изолирован** (sandboxed iframe + postMessage) —
   доверять чужим персонажам безопаснее, чем кажется, но ключи API (в мульти-API
   форках) — отдельная история (см. п. 4).

3. **Мульти-API форки = SillyTavern на Perchance.** Они оборачивают `ai-text-plugin`
   и маршрутизируют запросы, оставляя «фоновые» вызовы (память/саммари) на бесплатном
   движке. Большой контекст (до 800K у Gemini) — отсюда «хорошая память».

4. **Форкайте мульти-API чаты — это не паранойя, а необходимость.** Сам автор Gemini
   Chat жёстко требует форк: live-обновления + ваш API-ключ в IndexedDB = потенциальный
   вектор кражи при компрометации аккаунта автора. Это согласуется с общим советом
   про [community-плагины](../plugins/07-community-and-extra-plugins.md).

5. **«Uncensored» ≠ без модерации.** Аплоад персонажей проходит AI-модерацию
   (`disallowed_content`), а публичные галереи (URV) фильтруют ввод жёсткими regex.
   Без фильтров — обычно только приватный локальный чат.
