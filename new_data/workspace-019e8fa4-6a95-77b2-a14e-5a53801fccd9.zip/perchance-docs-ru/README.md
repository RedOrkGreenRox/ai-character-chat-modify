# 📚 Perchance — Полная документация на русском

> Неофициальный, но максимально полный русскоязычный пересказ документации
> **Perchance AI Character Chat** и **всех официальных плагинов Perchance**.
>
> Источники: <https://perchance.org/ai-character-chat-docs> и <https://perchance.org/plugins>
> Дата сборки: 2026-06-03.

Это структурированный перевод-адаптация: текст изложен на русском, а команды, код
и синтаксис сохранены как есть (с пояснениями), потому что именно их вы будете
вставлять в Perchance дословно.

---

## Часть 1. AI Character Chat (чат с AI-персонажами)

| # | Раздел | Файл |
|---|--------|------|
| 1 | 💡 Советы (Tips) | [chat/01-tips.md](chat/01-tips.md) |
| 2 | 🎭 Инструкция и Напоминание | [chat/02-instruction-and-reminder.md](chat/02-instruction-and-reminder.md) |
| 3 | 💬 Начальные сообщения | [chat/03-initial-messages.md](chat/03-initial-messages.md) |
| 4 | 🧠 Память и Лор | [chat/04-memories-and-lore.md](chat/04-memories-and-lore.md) |
| 5 | 🎨 Стилизация сообщений | [chat/05-message-styling.md](chat/05-message-styling.md) |
| 6 | 🧩 Пользовательский код (Custom Code) и API `oc` | [chat/06-custom-code.md](chat/06-custom-code.md) |
| 7 | 🧪 Примеры пользовательского кода | [chat/07-custom-code-examples.md](chat/07-custom-code-examples.md) |
| 8 | 🐍 Запуск Python-кода | [chat/08-running-python.md](chat/08-running-python.md) |

## Часть 2. Плагины Perchance

| Файл | Содержимое |
|------|-----------|
| [plugins/00-about-plugins.md](plugins/00-about-plugins.md) | Что такое плагины, как их подключать, официальные vs. сообщества |
| [plugins/01-ai-and-media.md](plugins/01-ai-and-media.md) | AI, изображения, аудио, голос (text-to-image, ai-text, TTS и т.п.) |
| [plugins/02-data-and-storage.md](plugins/02-data-and-storage.md) | Хранение данных, KV, секреты, загрузка файлов, URL-параметры |
| [plugins/03-randomness-and-lists.md](plugins/03-randomness-and-lists.md) | Случайность, выбор из списков, кости, колесо, фильтры |
| [plugins/04-ui-and-layout.md](plugins/04-ui-and-layout.md) | UI, вёрстка, кнопки, вкладки, фон, шрифты, навигация |
| [plugins/05-text-and-language.md](plugins/05-text-and-language.md) | Работа с текстом: числа в слова, склонения, markdown, title case |
| [plugins/06-misc-and-tools.md](plugins/06-misc-and-tools.md) | Прочие инструменты: миры, текстовые квесты, статистика, рисование |
| [plugins/07-community-and-extra-plugins.md](plugins/07-community-and-extra-plugins.md) | Дополнительные и community-плагины (link, power-*, icon, pronoun, gender и др.) |
| [plugins/99-full-index.md](plugins/99-full-index.md) | Полный алфавитный указатель всех официальных плагинов |

## Часть 3. Индекс генераторов сайта

| Файл | Содержимое |
|------|-----------|
| [generators/00-index.md](generators/00-index.md) | Подборка интересных генераторов: AI-чат и форки, генерация изображений, текста, инструменты, обучение |
| [generators/01-acc-forks.md](generators/01-acc-forks.md) | Подробный разбор форков AI Character Chat: NACG, URV AI, TPS, Gemini Chat и др. (фичи, авторы, компромиссы, как выбрать) |

## Часть 4. Аналитика

| Файл | Содержимое |
|------|-----------|
| [analysis/plugin-synergies.md](analysis/plugin-synergies.md) | Анализ синергий между плагинами: карта ролей, топ-комбо, готовые «рецепты», анти-синергии |
| [analysis/forks-code-analysis.md](analysis/forks-code-analysis.md) | Технический анализ исходного кода форков ACC (через `#edit`): архитектура, share-link, песочница, мульти-API обёртки, security |
| [analysis/fork-ai-character-chat-modify.md](analysis/fork-ai-character-chat-modify.md) | Разбор форка `ai-character-chat-modify`: оказался немодифицированной копией оригинала (преимущества/недостатки/недоделки) |

---

## Как этим пользоваться

- **Новичкам** — начните с `chat/01-tips.md` и `chat/02..05`.
- **Разработчикам** — `chat/06-custom-code.md` (API `oc`), затем примеры и Python.
- **Создателям генераторов** — раздел плагинов.

## Важные оговорки

- Perchance — живой проект, синтаксис и список плагинов могут меняться.
- Плагины «сообщества» (community) — неофициальные; их рекомендуется форкать.
- Данные чата хранятся в браузере пользователя — **делайте экспорт-бэкапы**.
