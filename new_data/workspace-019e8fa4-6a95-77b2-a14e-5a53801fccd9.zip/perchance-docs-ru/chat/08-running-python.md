# 🐍 Запуск Python-кода

Можно использовать **[Pyodide](https://github.com/pyodide/pyodide)** для выполнения Python прямо в браузере.

> ⚠️ Не все Python-пакеты пока работают в Pyodide, но поддержка расширяется с каждой версией. Запросить поддержку пакета/фичи можно [здесь](https://github.com/pyodide/pyodide/issues) (сначала поищите существующие issue).

---

## Базовая инициализация

Вставьте в поле custom code в расширенной области редактора персонажа:

```js
delete window.sessionStorage; window.sessionStorage = {}; // фикс бага pyodide перед загрузкой
await import("https://cdn.jsdelivr.net/pyodide/v0.26.3/full/pyodide.js");
let pyodide = await loadPyodide();
await pyodide.loadPackage("micropip");
```

После этого:
- `await pyodide.runPythonAsync("1+2+3")` — выполнить код;
- внутри Python: `await micropip.install("numpy")` — установить пакеты.

---

## Полный пример: персонаж выполняет код из блоков в своих сообщениях

Код ищет в сообщениях AI блоки ```` ```python ... ``` ````, выполняет их и добавляет вывод новым сообщением.

````js
delete window.sessionStorage; window.sessionStorage = {}; // фикс бага pyodide перед загрузкой
await import("https://cdn.jsdelivr.net/pyodide/v0.26.3/full/pyodide.js");

let pyodide = await loadPyodide({
  stdout: (line) => { printed.push(line); },
  stderr: (line) => { errors.push(line); },
});
let printed = [];
let errors = [];

console.log(pyodide.runPython(`
    import sys
    sys.version
`));
pyodide.runPython("print(1 + 2)");

await pyodide.loadPackage("micropip");

oc.thread.on("MessageAdded", async function() {
  let lastMessage = oc.thread.messages.at(-1);
  if(lastMessage.author !== "ai") return;
  let codeBlockMatches = [...lastMessage.content.matchAll(/```(?:python|py)?\n(.+?)\n```/gs)];
  if(codeBlockMatches.length > 0) {
    let code = codeBlockMatches.map(m => m[1]).join("\n"); // объединяем все блоки в один
    printed = [];
    errors = [];
    await pyodide.runPythonAsync(code).catch(e => errors.push(e.message));
    let content = "";
    if(printed.length > 0) content += `**Code Execution Output**:\n\n${printed.join("\n")}`;
    if(errors.length > 0) content += `\n\n**Code Execution Errors**:\n\n\`\`\`\n${errors.join("\n")}\n\`\`\``;
    if(!content.trim()) content = "(The code block in the previous message did not `print` anything - there was no output.)";
    oc.thread.messages.push({content, author:"user", expectsReply:false});
  }
});
````

**Готовый пример-персонаж** с этим кодом:
<https://perchance.org/ai-character-chat?data=Python_Helper~986c80bf8a26a3b156a5be6c34805540.gz>
