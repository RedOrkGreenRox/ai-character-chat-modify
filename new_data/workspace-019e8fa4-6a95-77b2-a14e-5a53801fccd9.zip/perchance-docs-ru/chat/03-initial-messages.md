# 💬 Начальные сообщения (Initial Messages)

Начальные сообщения помогают AI «войти в роль». Их формат позволяет:

- **Скрыть начальные сообщения от пользователя** — если их много и пользователю было бы неудобно видеть их при каждом новом чате.
- **Скрыть начальные сообщения от AI** — например, чтобы показать пользователю инструкции или указать автора персонажа (то, что должен видеть человек, но не AI).
- **Создавать системные сообщения** — для направления поведения AI или подачи контекста, который не должен «произноситься» ни AI, ни пользователем.

---

## Базовый формат

```
[AI]: This is the first AI message.
[USER]: This is the user's response.
[AI]: This is the second AI message.
[SYSTEM]: Here's a system message. Use system messages to help guide the AI.
```

## Скрытие сообщений

Скрыть от `user` или от `ai`:

```
[AI; hiddenFrom=user]: This message is spoken by the AI and is hidden from the user.
[SYSTEM; hiddenFrom=ai]: This message is spoken by the System and is hidden from the AI.
```

## Имя для сообщения

Задать/переопределить имя отправителя:

```
[SYSTEM; name=Bob]: This message is sent from Bob
```

## Комбинирование свойств

Несколько свойств — через запятую:

```
[SYSTEM; name=Bob, hiddenFrom=ai]: This message is sent from Bob and hidden from the ai
```

## Многострочные сообщения

Сообщение может занимать несколько строк:

```
[AI]: This is the first AI message.
It has two lines.
[USER]: This is the user's response.
It also has two lines.
```

## Markdown / HTML и картинки

Как и любые сообщения, начальные могут содержать **markdown/HTML**. Пример инструкции для пользователя со встроенной картинкой (скрытой от AI):

```
[SYSTEM; hiddenFrom=ai]: Hello there! Thanks for trying out my character. Here are some tips:
* Make sure to edit the character's response if they break character. You'll probably only have to do this for the first few messages, at most.
* ...

<img src="https://user.uploads.dev/file/b37af6315e6d2c76ff6c17185163c9d9.jpg">

See the latest versions of my characters at my twitter account: [@exampleusername](https://twitter.com/exampleusername)
```

---

> 🔗 Связь с другими разделами: этот же формат `[AI]:` / `[USER]:` / `[SYSTEM]:`
> используется в [инструкциях и напоминаниях](02-instruction-and-reminder.md).
> Разница: начальные сообщения **суммируются** при разрастании треда, а инструкции/напоминания — нет.
