# 🧩 Пользовательский код (Custom Code) и API `oc`

> 💡 **Лайфхак:** на оригинальной странице есть кнопка «Copy page» — скопируйте текст
> документации, вставьте в AI (ChatGPT/Claude) и попросите написать нужную
> функциональность для вашего персонажа.

В расширенных опциях создания персонажа есть поле **«custom code»** — туда можно вставить **JavaScript**, расширяющий возможности персонажа.

## Что можно сделать

- Дать персонажу **превращать/редактировать самого себя** (как стартовый персонаж «Unknown»).
- Дать персонажу **доступ в интернет** (например, просить его суммировать веб-страницы).
- **Улучшить память** — настроить собственную систему embedding/retrieval.
- Дать персонажу **голос** (через kokoro-js или встроенный в браузер text-to-speech).
- Позволить персонажу **выполнять свой JS или [Python](08-running-python.md)**.
- Дать возможность **создавать картинки** через Stable Diffusion.
- **Авто-удаление/повтор** сообщений с определёнными ключевыми словами.
- Менять **фон чата, стиль пузырей, аватары, музыку** в зависимости от происходящего в истории.

> 🔒 **Безопасность.** Пользовательский код выполняется в **песочнице (sandboxed iframe)**. Код чужого персонажа не имеет доступа к вашим настройкам и перепискам с другими персонажами — только к данным текущего персонажа и текущего разговора.

---

## Объект `oc`

Главная точка доступа. Сообщения треда лежат в `oc.thread.messages` — это массив:

```json5
[
  { author: "user", content: "Hello" },
  { author: "ai",   content: "Hi." },
  {
    author: "system",
    hiddenFrom: ["user"],   // может содержать "user" и/или "ai"
    expectsReply: false,    // AI не будет автоматически отвечать на это сообщение
    content: "Системное сообщение, скрытое от пользователя, на которое AI не ответит автоматически.",
  },
]
```

- Самое **свежее** сообщение — в конце массива.
- `author` бывает `user`, `ai` или `system`. `system` — для направления поведения AI и подачи контекста.

### Пример: замена `:)` на эмодзи во всех сообщениях

```js
oc.thread.on("MessageAdded", function({message}) {
  message.content = message.content.replaceAll(":)", "૮ ˶ᵔ ᵕ ᵔ˶ ა");
});
```

Сообщения можно **редактировать** (как выше), **удалять** (`pop`, `shift`, `splice`) и **добавлять** (`push`, `unshift`).

> Обработчик `MessageAdded` может быть `async` — он будет «awaited», то есть ваш код гарантированно завершится **до** ответа AI.

### Пример: случайный цвет текста через `wrapperStyle`

```js
oc.thread.on("MessageAdded", function({message}) {
  let red = Math.round(Math.random()*255);
  let green = Math.round(Math.random()*255);
  let blue = Math.round(Math.random()*255);
  message.wrapperStyle = `color:rgb(${red}, ${green}, ${blue});`;
});
```

---

## Полный список свойств `oc`

### `oc.character`
- **`name`** — строка (имя).
- **`avatar`** — `url` (ссылка на картинку), `size` (кратность дефолтного размера, по умолч. `1`), `shape` (`circle` / `square` / `portrait`).
- **`roleInstruction`** — строка с описанием персонажа и его роли.
- **`reminderMessage`** — строка-напоминание.
- **`initialMessages`** — массив объектов-сообщений (свойства см. в `thread.messages`).
- **`customCode`** — да, персонаж может редактировать **собственный** код.
- **`imagePromptPrefix`** — текст, добавляемый **перед** промптом всех картинок, генерируемых AI.
- **`imagePromptSuffix`** — текст **после** промпта.
- **`imagePromptTriggers`** — каждая строка вида `trigger phrase: description of the thing` (примеры в редакторе).
- **`shortcutButtons`** — массив объектов вида `{autoSend:false, insertionType:"replace", message:"/ai be silly", name:"silly response", clearAfterSend:true}`.
  - `insertionType`: `replace`, `prepend` (перед текстом), `append` (после текста).
  - `clearAfterSend`, `autoSend`: `true`/`false`.
  - `name` — подпись кнопки; `message` — содержимое для отправки/вставки.
  - ⚠️ При создании нового треда снимок этих кнопок копируется в тред. Чтобы менять кнопки **текущего треда**, редактируйте `oc.thread.shortcutButtons`. Меняйте `oc.character.shortcutButtons` только для **будущих** тредов.
- **`streamingResponse`** — `true`/`false` (по умолч. `true`).
- **`customData`** — объект для произвольных данных.
  - `PUBLIC` — особое под-свойство, которое **передаётся в ссылках-шарингах персонажа**.

### `oc.thread`
- **`name`** — строка.
- **`messages`** — массив сообщений, у каждого:
  - `content` — **обязательно** — текст; может включать HTML, рендерится как **markdown** по умолчанию (см. `oc.messageRenderingPipeline`).
  - `author` — **обязательно** — `user` / `ai` / `system`.
  - `name` — переопределяет имя. Если не задано: для AI — `oc.thread.character.name`, иначе `oc.character.name`. Для user: `oc.thread.userCharacter.name` → `oc.character.userCharacter.name` → `oc.userCharacter.name` (read-only). Для system: `oc.thread.systemCharacter.name` → `oc.character.systemCharacter.name`.
  - `hiddenFrom` — массив, может содержать `user`, `ai`, оба или ничего.
  - `expectsReply` — `true` (ответит), `false` (не ответит), `undefined` (поведение по умолчанию: отвечает на сообщения пользователя, но не на свои).
  - `customData` — хранилище данных конкретного сообщения.
  - `avatar` — переопределяет аватар для этого сообщения (`url`, `size`, `shape`).
  - `wrapperStyle` — CSS пузыря, напр. `"background:white; border-radius:10px; color:grey;"`.
  - `instruction` — инструкция из `/ai <instruction>` или `/user <instruction>` (используется при нажатии «regenerate»).
  - `scene` — самая свежая сцена считается «активной»:
    - `background`: `url` (картинка/видео), `filter` ([CSS filter](https://developer.mozilla.org/en-US/docs/Web/CSS/filter), напр. `hue-rotate(90deg); blur(5px)`).
    - `music`: `url` (аудио или видео), `volume` (0–1).
- **`character`** — переопределения персонажа для треда: `name`, `avatar` (`url`/`size`/`shape`), `reminderMessage`, `roleInstruction`.
- **`userCharacter`** — переопределения user-персонажа: `name`, `avatar`.
- **`systemCharacter`** — переопределения system-персонажа: `name`, `avatar`.
- **`customData`** — данные конкретного треда.
- **`messageWrapperStyle`** — CSS для всех сообщений треда, кроме тех, где задан `message.wrapperStyle`.
- **`shortcutButtons`** — см. `oc.character.shortcutButtons`.

### `oc.messageRenderingPipeline`
Массив функций обработки сообщений перед показом пользователю и/или AI (см. ниже).

> Многих свойств персонажа **нет в UI редактора**. Например, добавить стоп-последовательность можно только кодом:
> ```js
> oc.character.stopSequences = [":)"];
> ```

---

## Пример: дать AI «читать» веб-страницы и PDF по ссылке

```js
async function getPdfText(data) {
  let doc = await window.pdfjsLib.getDocument({data}).promise;
  let pageTexts = Array.from({length: doc.numPages}, async (v,i) => {
    return (await (await doc.getPage(i+1)).getTextContent()).items.map(token => token.str).join('');
  });
  return (await Promise.all(pageTexts)).join(' ');
}

oc.thread.on("MessageAdded", async function ({message}) {
  if(message.author === "user") {
    let urlsInLastMessage = [...message.content.matchAll(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g)].map(m => m[0]);
    if(urlsInLastMessage.length === 0) return;
    if(!window.Readability) window.Readability = await import("https://esm.sh/@mozilla/readability@0.4.4?no-check").then(m => m.Readability);
    let url = urlsInLastMessage.at(-1);
    let blob = await fetch(url).then(r => r.blob());
    let output;
    if(blob.type === "application/pdf") {
      if(!window.pdfjsLib) {
        window.pdfjsLib = await import("https://cdn.jsdelivr.net/npm/pdfjs-dist@3.6.172/+esm").then(m => m.default);
        pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.6.172/build/pdf.worker.min.js";
      }
      let text = await getPdfText(await blob.arrayBuffer());
      output = text.slice(0, 5000); // только первые 5000 символов
    } else {
      let html = await blob.text();
      let doc = new DOMParser().parseFromString(html, "text/html");
      let article = new Readability(doc).parse();
      output = `# ${article.title || "(no page title)"}\n\n${article.textContent}`;
      output = output.slice(0, 5000);
    }
    oc.thread.messages.push({
      author: "system",
      hiddenFrom: ["user"],
      content: "Here's the content of the webpage that was linked in the previous message: \n\n"+output,
    });
  }
});
```

## Пример: своя команда `/charname`

```js
oc.thread.on("MessageAdded", async function ({message}) {
  let m = message;
  if(m.author === "user" && m.content.startsWith("/charname ")) {
    oc.character.name = m.content.replace(/^\/charname /, "");
    oc.thread.messages.pop(); // удаляем сообщение-команду
  }
});
```

---

## События (Events)

У каждого события есть объект `message`; у `MessageDeleted` дополнительно `originalIndex`.

- `oc.thread.on("MessageAdded", ({message}) => {...})` — сообщение добавлено в конец треда (срабатывает **после** полной генерации).
- `oc.thread.on("MessageEdited", ({message}) => {...})` — сообщение отредактировано или перегенерировано.
- `oc.thread.on("MessageInserted", ({message}) => {...})` — сообщение вставлено (через попап редактирования).
- `oc.thread.on("MessageDeleted", ({message, originalIndex}) => {...})` — пользователь удалил сообщение (кнопка корзины).
- `oc.thread.on("MessageStreaming", (data) => {...})` — см. раздел «Стриминг» ниже.

`message` — это **реальная ссылка** на объект, его можно править напрямую:

```js
oc.thread.on("MessageAdded", function({message}) {
  message.content += "blah";
});
```

Получить **индекс** отредактированного сообщения:

```js
oc.thread.on("MessageEdited", function({message}) {
  let editedMessageIndex = oc.thread.messages.findIndex(m => m === message);
});
```

---

## Рендеринг сообщений (`messageRenderingPipeline`)

Иногда нужно показывать пользователю не то, что видит AI. Для этого — массив `oc.messageRenderingPipeline`, в который вы `.push()` функцию. Параметр `reader` — кто «читает» (`user` или `ai`).

```js
oc.messageRenderingPipeline.push(function({message, reader}) {
  if(reader === "user") message.content += "🌸";                 // пользователь увидит цветок
  if(reader === "ai") message.content = message.content.replaceAll("wow", "WOW"); // AI увидит "wow" заглавными
});
```

---

## Визуальный вывод и ввод от пользователя

Код выполняется внутри iframe. Его можно **показать** `oc.window.show()` и **скрыть** `oc.window.hide()`. Пользователь может перетаскивать и менять размер встроенного окна. Контент выводится как обычно: `document.body.innerHTML = "hello world"`.

Применения: динамический видео/gif-аватар, реагирующий на эмоцию сообщения; вывод результата p5.js-кода, который персонаж помогает писать; и т.д.

---

## Использование AI в своём коде

Можно вызывать LLM/изображения прямо из кода: `oc.generateText` и `oc.textToImage`.

**`oc.generateText`** (параметры см. на [ai-text-plugin](../plugins/01-ai-and-media.md)):

```js
let result = await oc.generateText({
  instruction: "Write the first paragraph of a story about fantasy world.",
  startWith: "Once upon a",   // необязательно — заставить начать с этого текста
  stopSequences: ["\n"],       // необязательно — остановиться на переводе строки
});
```

- `result.text` — весь текст (включая `startWith`).
- `result.generatedText` — только то, что сгенерировал AI после `startWith`.
- Обязателен только `instruction`.

**`oc.textToImage`** (параметры см. на [text-to-image-plugin](../plugins/01-ai-and-media.md)):

```js
let result = await oc.textToImage({
  prompt: "anime style digital art of a sentient robot, forest background, painterly textures",
  negativePrompt: "night time, blurry",  // необязательно
});
```

- `result.dataUrl` — data-URL вида `data:image/jpeg;base64,...`. Обращайтесь с ним как с обычной ссылкой на картинку.

**Пример: дописать эмодзи в каждое сообщение через AI:**

```js
oc.thread.on("MessageAdded", async function({message}) {
  let result = await oc.generateText({
    instruction: `Please edit the following message to have more emojis:\n\n---\n${message.content}\n---\n\nReply with only the above message (the content between ---), but with more (relevant) emojis.`,
  });
  message.content = result.trim().replace(/^---|---$/g, "").trim();
});
```

---

## Хранение данных

- В треде: `oc.thread.customData.foo = 10`
- В сообщении: `message.customData.foo = 10`
- В персонаже: `oc.character.customData.foo = 10` (но **не** попадает в ссылки-шаринги).
- В персонаже **с сохранением в ссылках-шарингах**: под `oc.character.customData.PUBLIC`, напр. `oc.character.customData.PUBLIC = {foo:10}`.

---

## Стриминг сообщений

(«Реальный» пример — код плагина text-to-speech.)

```js
oc.thread.on("StreamingMessage", async function (data) {
  for await (let chunk of data.chunks) {
    console.log(chunk.text); // chunk.text — небольшой фрагмент текста
  }
});
```

---

## Интерактивные сообщения (кнопки)

Можно использовать `onclick` в сообщениях, чтобы пользователь действовал кликом, а не печатал:

```html
What would you like to do?
1. <button onclick="oc.thread.messages.push({author:'user', content:'Fight'});">Fight</button>
2. <button onclick="oc.thread.messages.push({author:'user', content:'Run'});">Run</button>
```

Рекомендуется не хранить HTML в сообщениях (он тратит токены и путает AI), а использовать `oc.messageRenderingPipeline` и собственный компактный формат, например `[[Fight]]`:

```html
What would you like to do?
1. [[Fight]]
2. [[Run]]
```

Инструкция персонажу-«гейммастеру»:

```
You are a game master. You creatively and engagingly simulate a world for the user. The user takes actions, and you describe the consequences.

Your messages should end with a list of possible actions, and each action should be wrapped in double-square brackets like this:

Actions:
1. [[Say sorry]]
2. [[Turn and run]]
```

И код, превращающий `[[...]]` в кнопки **только для пользователя**:

```js
oc.messageRenderingPipeline.push(function({message, reader}) {
  if(reader === "user") {
    message.content = message.content.replace(/\[\[(.+?)\]\]/g, (match, text) => {
      let encodedText = encodeURIComponent(text); // защита от кавычек, ломающих onclick
      return `<button onclick="oc.thread.messages.push({author:'user', content:decodeURIComponent('${encodedText}')});">${text}</button>`;
    });
  }
});
```

> ⚠️ Внутри `onclick` нельзя использовать `this` и `event` — код просто отправляется в ваш iframe и выполняется там, реального элемента, вызвавшего обработчик, нет.

---

## Подводные камни (Gotchas)

### «`<function>` is not defined» в обработчиках кликов

Этот код **не сработает**:

```js
function hello() { console.log("hi"); }
document.body.innerHTML = `<div onclick="hello()">click me</div>`;
oc.window.show();
```

Причина: весь код выполняется внутри `<script type=module>`, поэтому функции нужно делать **глобальными**, чтобы они были доступны из обработчиков **снаружи** модуля:

```js
window.hello = function() { console.log("hi"); }
```

---

## FAQ

**Можно ли запустить функцию ПЕРЕД ответом AI — после сообщения пользователя, но до ответа бота?**
Да. Событие `MessageAdded` срабатывает на каждое добавленное сообщение. Проверяйте автора:

```js
if(oc.thread.messages.at(-1).author === "user") {
  // этот код выполнится сразу после ответа пользователя и ДО ответа AI
}
```
