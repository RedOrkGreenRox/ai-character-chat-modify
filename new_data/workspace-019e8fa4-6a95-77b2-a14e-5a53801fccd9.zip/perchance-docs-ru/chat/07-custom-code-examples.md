# 🧪 Примеры пользовательского кода

> Во всех примерах используется `oc.generateText({instruction:"...", startWith:"..."})`
> из раздела [Custom Code](06-custom-code.md).

---

## 1. Шаг «доработки» (refinement) для сообщений персонажа

После генерации сообщение редактируется AI по вашей инструкции. Поменяйте текст инструкции «include more emojis…» на свой и вставьте в поле custom code.

```js
oc.thread.on("MessageAdded", async function() {
  let lastMessage = oc.thread.messages.at(-1);
  if(lastMessage.author !== "ai") return; // правим только сообщения AI

  let instruction = `
Here's a message:
---
${lastMessage.content}
---
Please rewrite this message to include more emojis. Respond with only the rewritten message - nothing more, nothing less.
`.trim();
  let response = await oc.generateText({instruction});
  lastMessage.content = response;
});
```

---

## 2. Запретить персонажу действовать за вас в ролеплее

Удаляет из ответа AI действия, приписанные вашему персонажу или другим, оставляя только действия самого персонажа.

```js
oc.thread.on("MessageAdded", async function () {
  let lastMessage = oc.thread.messages.at(-1);

  if(lastMessage.author === "ai") {
    let instruction = `Please edit the following message so that it only contains actions taken by ${lastMessage.name} and not by ${oc.thread.userCharacter.name} or any other characters. Remove actions from characters other than ${lastMessage.name} in this message:\n\n---\n${lastMessage.content}\n---\n\nReply with the edited version of the above message which only includes ${lastMessage.name}'s first action/speech/etc. Your reply must not include follow-on actions by other characters.`;
    let result = await oc.generateText({instruction});
    lastMessage.content = result.trim().replace(/^---|---$/g, "").trim();
  }
});
```

---

## 3. Добавить картинку по предсказанной мимике/эмоции сообщения

Идея: после каждого сообщения AI классифицируется его эмоция, и к сообщению добавляется подходящая картинка/GIF (демо — персонаж «Nick Wilde» из Зверополиса).

Как это работает:
- `oc.thread.on("MessageAdded", ...)` — триггер.
- `oc.generateText` — классифицирует сообщение в одну из заданных эмоций.
- Обёртка `<!--hidden-from-ai-start-->...<!--hidden-from-ai-end-->` скрывает добавленную картинку от AI, чтобы он не начал выдумывать свои URL по образцу.

> 📝 **Примечание автора Perchance:** теперь существует [`oc.messageRenderingPipeline`](06-custom-code.md), и для такого рода задач он, вероятно, **лучший** подход, чем дописывание HTML в `content`.

Список `<эмоция>: <url>` можно заменить своим. Несколько URL на одну метку разделяются `|` (выбирается случайный):

```js
// Можно указать несколько URL на одну метку — выберется случайный.
// Разделяйте URL символом "|" так:
// <expression>: https://example.com/image1.jpg | https://example.com/image2.jpg

let expressions = `

neutral, happy: https://user.uploads.dev/file/78f6e4c722a85bad99ee4df3ab97541b.jpg
horrified, shocked: https://user.uploads.dev/file/82d3a801868fdc5a7c14f1cf894f3a09.jpg
drunk: https://user.uploads.dev/file/5a1f541b1127097bbf7d7683a469d008.jpg
angry: https://user.uploads.dev/file/15dbde849acf39f987935b3c5b6f8d3a.jpg
sly: https://user.uploads.dev/file/52b836e9a7b820fa5692049524a5d554.jpg
concerned: https://user.uploads.dev/file/96339420d329a03d45954c26b12cdf7c.jpg
worried, scared: https://user.uploads.dev/file/6f3ed881102fdc617ba5c37367da4a28.jpg
happy, optimistic: https://user.uploads.dev/file/2a1f828ca2abe5a7a9acd98d31711d95.jpg
disappointed: https://user.uploads.dev/file/fe7cf5877474db1341d42f10be024183.jpg
wacky, crazy, fun: https://user.uploads.dev/file/5a4f65a9d22889a1d84545ca0aed824d.jpg

`.trim().split("\n").map(l => [l.trim().split(":")[0].trim(), l.trim().split(":").slice(1).join(":").trim().split("|").map(url => url.trim())]).map(a => ({label:a[0], url:a[1]}));

let numMessagesInContext = 4; // сколько прошлых сообщений давать для контекста при классификации

oc.thread.on("MessageAdded", async function() {
  let lastMessage = oc.thread.messages.at(-1);
  if(lastMessage.author !== "ai") return;

  let questionText = `I'm about to ask you to classify the facial expression of a particular message, but here's some context first:

---
${oc.thread.messages.slice(-numMessagesInContext).filter(m => m.author!=="system").map(m => (m.author=="ai" ? `[${oc.character.name}]: ` : `[Anon]: `)+m.content).join("\n\n")}
---

Okay, now that you have the context, please classify the facial expression of the following text:

---
${lastMessage.content}
---

Choose between the following categories:

${expressions.map((e, i) => `${i}) ${e.label}`).join("\n")}

Please respond with the number which corresponds to the facial expression that most accurately matches the given message. Respond with just the number - nothing else.`;

  let instruction = `You are a helpful assistant that classifies the hypothetical facial expression of particular text messages.\n\n${questionText}`;
  let response = await oc.generateText({instruction});
  let index = parseInt(response.split(")")[0].replace(/[^0-9]/g, ""));
  let expressionObj = expressions[index];
  let chosenUrl = expressionObj.url[Math.floor(Math.random()*expressionObj.url.length)];
  let image = `<img style="height:70px;" src="${chosenUrl}" title="${expressionObj.label.replace(/[^a-zA-Z0-9_\- ]/g, "")}">`;
  lastMessage.content += `<!--hidden-from-ai-start--><br>${image}<!--hidden-from-ai-end-->`;
});
```

---

## Другие идеи (упоминаются в документации)

- **Авто-удаление/повтор** сообщений, содержащих определённые ключевые слова.
- **Импорт/скрейпинг** контента веб-страниц и PDF (см. пример в [Custom Code](06-custom-code.md)).
- **Смена фона/музыки/аватара** в зависимости от происходящего в истории (через `message.scene`).
- **Автоматизация** — запуск своих функций до/после ответа AI (см. FAQ в [Custom Code](06-custom-code.md)).
